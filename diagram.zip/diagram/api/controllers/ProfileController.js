module.exports = {

    render : function(res,req){
        console.log(req);
    },

};
